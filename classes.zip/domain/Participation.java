package cat.politecnicllevant.examen2526.pelat.domain;

public class Participation {
    private Long id;
    private Long athleteId;
    private Long eventId;
    private String result;
    private Integer position;
}

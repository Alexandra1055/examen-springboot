package cat.politecnicllevant.examen2526.pelat.domain;

import cat.politecnicllevant.examen2526.domain.Sex;

public class Athlete {
    private Long id;
    private String name;
    private String country;
    private Integer age;
    private Sex sex;
}

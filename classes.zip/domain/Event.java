package cat.politecnicllevant.examen2526.pelat.domain;

import cat.politecnicllevant.examen2526.domain.EventCategory;
import cat.politecnicllevant.examen2526.domain.Sex;

public class Event {
    private Long id;
    private String name;
    private EventCategory category;
    private Sex sex;
    private boolean finished;
}

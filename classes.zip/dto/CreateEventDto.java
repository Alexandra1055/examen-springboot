package cat.politecnicllevant.examen2526.pelat.dto;

import cat.politecnicllevant.examen2526.domain.EventCategory;
import cat.politecnicllevant.examen2526.domain.Sex;

public class CreateEventDto {
    private String name;
    private EventCategory category;
    private Sex sex;
    private Boolean finished;
}

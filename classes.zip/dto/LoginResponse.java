package cat.politecnicllevant.examen2526.pelat.dto;

public class LoginResponse {
    private String token;
}

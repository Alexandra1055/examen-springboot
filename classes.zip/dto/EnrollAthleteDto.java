package cat.politecnicllevant.examen2526.pelat.dto;

public class EnrollAthleteDto {
    private Long athleteId;
    private Long eventId;
}

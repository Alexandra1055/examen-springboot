package cat.politecnicllevant.examen2526.pelat.dto;

import cat.politecnicllevant.examen2526.domain.Sex;

public class CreateAthleteDto {
    private String name;
    private String country;
    private Integer age;
    private Sex sex;
}

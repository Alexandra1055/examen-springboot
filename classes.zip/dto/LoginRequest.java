package cat.politecnicllevant.examen2526.pelat.dto;

public class LoginRequest {
    private String email;
    private String password;
}
